
let studyData = {
  "Net Interest Margin (NIM)": "Definition:\nNIM measures how profitable a bank is from lending/investing activities relative to funding costs.\n\nKey Formula:\nNIM = (Interest Income - Interest Expense) / Earning Assets\n\nCore Concepts:\n- Banks gather deposits cheaply\n- Banks lend/invest at higher rates\n- The spread drives profitability\n\nImportant Terms:\n- Deposit spread\n- Deposit beta\n- Operational deposits\n- Excess deposits\n",
  "ACH": "ACH = Automated Clearing House\n\nCharacteristics:\n- Batch processed\n- Low cost\n- Not real-time\n\nUsed for:\n- Payroll\n- Vendor payments\n- Recurring payments\n\nACH Credit = push payment\nACH Debit = pull payment\n",
  "Wires": "Wire transfers are:\n- Faster\n- Final settlement\n- High-value payments\n\nUsed for:\n- Urgent transfers\n- Large corporate payments\n- M&A transactions\n\nKey Systems:\n- Fedwire\n- CHIPS\n",
  "RTP & FedNow": "Real-time payment infrastructure.\n\nBenefits:\n- 24/7 settlement\n- Immediate funds movement\n- Better treasury visibility\n- Faster reconciliation\n\nKey Networks:\n- RTP (The Clearing House)\n- FedNow (Federal Reserve)\n",
  "ISO 20022": "Modern financial messaging standard.\n\nBenefits:\n- Richer payment data\n- Better automation\n- Improved reconciliation\n- Enhanced compliance processing\n\nImportant for:\n- Treasury modernization\n- ERP integration\n- Cross-border standardization\n"
};
let currentTopic = null;

function renderTopics() {
  const list = document.getElementById('topicList');
  list.innerHTML = '';

  Object.keys(studyData).forEach(topic => {
    const li = document.createElement('li');
    li.textContent = topic;
    li.onclick = () => openTopic(topic);
    list.appendChild(li);
  });
}

function openTopic(topic) {
  currentTopic = topic;
  document.getElementById('topicTitle').textContent = topic;
  document.getElementById('topicContent').value = studyData[topic];
}

function saveNotes() {
  if (!currentTopic) return;
  studyData[currentTopic] = document.getElementById('topicContent').value;
  localStorage.setItem('studyGuideData', JSON.stringify(studyData));
  alert('Notes saved locally!');
}

function addTopic() {
  const input = document.getElementById('newTopic');
  const topic = input.value.trim();

  if (!topic) return;

  studyData[topic] = 'Add your notes here...';
  renderTopics();
  openTopic(topic);
  input.value = '';
}

function exportData() {
  const blob = new Blob([JSON.stringify(studyData, null, 2)], {type: 'application/json'});
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'study-guide-backup.json';
  link.click();
}

window.onload = () => {
  const saved = localStorage.getItem('studyGuideData');

  if (saved) {
    studyData = JSON.parse(saved);
  }

  renderTopics();

  const firstTopic = Object.keys(studyData)[0];
  if (firstTopic) {
    openTopic(firstTopic);
  }
};
